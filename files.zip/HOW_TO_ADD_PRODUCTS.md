# Lookup! Kids Wear — How to add products & go live (free)

Your site has 3 files:
- `index.html` — the website itself (don't need to touch this)
- `admin.html` — your **admin panel**. Use this to add/edit/delete products with a form — no editing code by hand.
- `products.json` — the product list. The admin panel edits this file for you automatically.

Right now `products.json` is empty (`[]`) — that's why the site shows "Coming Soon."

## Step 1 — Put the site online (so you can edit it from anywhere, even your phone)

1. Go to **github.com** and make a free account.
2. Click **+ → New repository**. Name it `lookup-kidswear`. Keep it **Public**. Click **Create repository**.
3. Click **Add file → Upload files**, then drag in `index.html`, `admin.html`, and `products.json`. Click **Commit changes**.
4. Go to **Settings → Pages** (left sidebar). Under "Build and deployment", set Source to **Deploy from a branch**, Branch = `main`, folder = `/ (root)`. Click **Save**.
5. Wait 1–2 minutes, refresh that page — you'll see your live link, something like:
   `https://yourusername.github.io/lookup-kidswear/`

That link is your live website — this is what you share with customers.
Your admin panel lives at: `https://yourusername.github.io/lookup-kidswear/admin.html` — **keep this link private**, don't put it in your Instagram bio or share it publicly, since anyone with the link and your token can edit products.

## Step 2 — Get a free access token (one-time setup, ~2 minutes)

The admin panel needs permission to save changes to your repository. This is what a token does.

1. Go to **github.com/settings/tokens?type=beta**
2. Click **Generate new token**
3. Under "Repository access" → choose **Only select repositories** → pick `lookup-kidswear`
4. Under "Permissions" → **Repository permissions** → set **Contents** to **Read and write**
5. Click **Generate token**, then **copy it immediately** (GitHub only shows it once). Paste it somewhere safe temporarily, like your Notes app — you'll need it each time you log into the admin panel.

## Step 3 — Add, edit or delete products (no coding, just a form)

1. Open your admin panel link: `https://yourusername.github.io/lookup-kidswear/admin.html`
2. Sign in with your GitHub username, repo name (`lookup-kidswear`), and the token from Step 2.
3. Tap the **+** button (bottom right) to add a product — fill in the name, category, price, MRP, photo link and badge, then **Save Product**.
4. Leave **Price** blank for any product you haven't finalized yet — the live site will automatically show "Price coming soon" and a "Notify Me" button instead of "Add to Cart," which is perfect until 23rd August.
5. Use the ✏️ and 🗑️ icons next to any product to edit or delete it.
6. Every save updates your live site directly — refresh your website after a few seconds to see the change.

You'll need to paste your token in again each time you open the admin panel (it's not saved anywhere, for your security) — everything else you entered stays as-is if you don't close the tab.

## Notes
- The admin panel is the easiest way to manage products day-to-day. If you ever prefer, you can still open `products.json` directly on github.com and edit the text — same result, just more manual.
- Price/MRP are plain numbers, no ₹ symbol or commas needed — the site adds that for you.
- Photo link (optional) — paste any image URL. Leave blank and a matching category icon shows instead.
- If sign-in fails, double check the username/repo name spelling and that the token has "Contents: Read and write" permission for that repo.
